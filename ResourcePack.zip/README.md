# 🎨 LobbySelector Resource Pack

Offizielles Resource Pack für das LobbySelector Plugin mit Custom Texturen und Models.

## 📦 Inhalt

```
ResourcePack/
├── pack.mcmeta                          # Resource Pack Metadaten
├── TEXTUR_ANLEITUNG.md                 # Ausführliche Textur-Anleitung
├── generate_textures.py                # Auto-Textur Generator (Python)
├── compile_resourcepack.bat             # Compiler (Windows Batch)
├── compile_resourcepack.ps1             # Compiler (PowerShell)
│
└── assets/minecraft/
    ├── models/item/
    │   ├── beacon.json                 # ROYALE Mode Model
    │   ├── diamond_sword.json          # SWORDS Mode Model
    │   ├── oak_door.json               # LOBBY Mode Model
    │   ├── tropical_fish.json          # Sharks Item
    │   ├── gold_block.json             # Gold Display
    │   └── chest.json                  # Treasure Chest
    │
    └── textures/custom/
        ├── royale_mode.png             # (64x64) ROYALE Textur
        ├── swords_mode.png             # (64x64) SWORDS Textur
        ├── lobby_mode.png              # (64x64) LOBBY Textur
        ├── tropical_fish_custom.png    # (16x16) Sharks
        └── treasure_chest.png          # (64x64) Treasure Chest
```

## 🚀 Quick-Start

### Methode 1: Automatisch mit Python (Empfohlen)

```powershell
cd "c:\Users\Simon\Desktop\Development\MinecraftPlugins\LobbySelector\ResourcePack"

# Texturen generieren
python generate_textures.py

# Resource Pack kompilieren
.\compile_resourcepack.ps1
```

### Methode 2: Manuell mit Batch

```powershell
cd "c:\Users\Simon\Desktop\Development\MinecraftPlugins\LobbySelector\ResourcePack"
.\compile_resourcepack.bat
```

## 📝 Texturen erstellen/anpassen

Siehe **TEXTUR_ANLEITUNG.md** für detaillierte Anleitung!

### Einfache Texturen (Auto-Generator)
```bash
python generate_textures.py
```
Erstellt automatisch alle Texturen im PNG-Format.

### Professionelle Texturen (Manuell)
1. Öffne GIMP oder Photoshop
2. Siehe TEXTUR_ANLEITUNG.md für Farben & Design
3. Speichere als PNG in `assets/minecraft/textures/custom/`

## 🔧 Installation auf Server

### 1. Resource Pack kompilieren
```powershell
.\compile_resourcepack.ps1
```
→ Erstellt `LobbySelector-RP.zip`

### 2. Zur Server kopieren
```powershell
Copy-Item "LobbySelector-RP.zip" `
          "c:\Users\Simon\Desktop\Development\Minecraft\PAPER-1.21.11\resourcepacks\"
```

### 3. server.properties anpassen

**Öffne:** `c:\Users\Simon\Desktop\Development\Minecraft\PAPER-1.21.11\server.properties`

**Füge/Ändere diese Zeilen:**
```properties
# Wenn die Zeilen nicht existieren, füge sie am Ende hinzu
resource-pack=LobbySelector-RP.zip
require-resource-pack=true
```

Optional (für Sicherheit):
```properties
resource-pack-sha1=<HASH>
```

### 4. Server neustarten
```
/reload confirm
# oder vollständiger Restart
```

### 5. Spieler sehen Prompt
Beim Beitreten: "Accept or Decline Resource Pack?"
→ Spieler akzeptiert die Custom Texturen

## 📋 Textur-Checkliste

- ☐ Alle PNG-Dateien vorhanden
  - `royale_mode.png`
  - `swords_mode.png`
  - `lobby_mode.png`
  - `tropical_fish_custom.png`
  - `treasure_chest.png`
- ☐ Alle JSON Models vorhanden
- ☐ pack.mcmeta aktualisiert (falls nötig)
- ☐ Resource Pack kompiliert zu ZIP
- ☐ ZIP auf Server kopiert
- ☐ server.properties aktualisiert
- ☐ Server neu gestartet

## 🎨 Farb-Codes

| Mode | Farben | Hex |
|------|--------|-----|
| ROYALE | Gold, Gelb | #FFD700, #FFFF00 |
| SWORDS | Rot, Orange | #FF4444, #FF8888 |
| LOBBY | Blau, Grün | #0066FF, #00FF00 |

## 🐛 Troubleshooting

### Resource Pack wird nicht geladen
- Überprüfe `resource-pack=LobbySelector-RP.zip` in server.properties
- ZIP-Datei sollte in `resourcepacks/` sein
- Server neustarten

### Texturen sind unsichtbar
- Stelle sicher, dass alle PNG-Dateien existieren
- Überprüfe Dateinamen (case-sensitive!)
- Prüfe JSON Model-Pfade

### Spieler sehen nur Standard-Items
- `/reload confirm` kann Resource Pack nicht neu laden
- Server muss komplett neu gestartet werden

## 🔗 Texturgröße & Format

| Dateityp | Größe | Format |
|----------|-------|--------|
| Item Textur | 64x64 px | PNG (RGBA) |
| Block Textur | 16x16 px | PNG (RGBA) |
| Entity | Variabel | PNG (RGBA) |

**Wichtig:** Transparenz (Alpha-Kanal) verwenden!

## 📚 Ressourcen

- [Minecraft Wiki - Resource Packs](https://minecraft.wiki/w/Resource_pack)
- [Minecraft JSON Model Format](https://minecraft.wiki/w/Model)
- [GIMP - Kostenlos](https://www.gimp.org/)
- [Paint.NET - Kostenlos](https://www.getpaint.net/)
- [Piskel - Online, Kostenlos](https://www.piskelapp.com/)

## ⚙️ JSON Model anpassen

Bearbeite die `*.json` Dateien in `assets/minecraft/models/item/` um:
- Custom 3D Rotationen
- Skalierung
- Anzeigeposition

Beispiel:
```json
{
  "parent": "item/handheld",
  "textures": {
    "layer0": "custom/royale_mode"
  },
  "display": {
    "gui": {
      "rotation": [20, -40, -20],
      "translation": [2, 3, 0],
      "scale": [0.8, 0.8, 0.8]
    }
  }
}
```

## 📊 File-Struktur Validierung

```powershell
# Überprüfe alle wichtigen Dateien
Test-Path "pack.mcmeta"
Test-Path "assets/minecraft/models/item/beacon.json"
Test-Path "assets/minecraft/textures/custom/royale_mode.png"
```

---

**Version:** 1.0  
**Kompatibilität:** Minecraft 1.21.11 (Paper Server)  
**Format:** 42 (1.21+)
