# LobbySelector Resource Pack - Compile Script (PowerShell)
# Starte mit: PowerShell -ExecutionPolicy Bypass -File compile_resourcepack.ps1

param(
    [switch]$SkipTextures = $false,
    [switch]$SkipCompress = $false
)

$ErrorActionPreference = "Stop"

# Farben
$Success = "Green"
$Error = "Red"
$Warning = "Yellow"
$Info = "Cyan"

Write-Host ""
Write-Host "========================================" -ForegroundColor $Info
Write-Host " LobbySelector - Resource Pack Compiler" -ForegroundColor $Info
Write-Host "========================================" -ForegroundColor $Info
Write-Host ""

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$resourcePackDir = Join-Path $scriptPath "ResourcePack"
$outputZip = Join-Path $scriptPath "LobbySelector-RP.zip"

# Überprüfe Verzeichnis
if (-not (Test-Path $resourcePackDir)) {
    Write-Host "[ERROR] ResourcePack Verzeichnis nicht gefunden!" -ForegroundColor $Error
    Write-Host "Erwartet: $resourcePackDir" -ForegroundColor $Warning
    exit 1
}

# Überprüfe pack.mcmeta
if (-not (Test-Path (Join-Path $resourcePackDir "pack.mcmeta"))) {
    Write-Host "[ERROR] pack.mcmeta nicht gefunden!" -ForegroundColor $Error
    exit 1
}

# === TEXTUR GENERIERUNG ===
if (-not $SkipTextures) {
    Write-Host "[1/3] Generiere Texturen mit Python..." -ForegroundColor $Info
    
    $pythonScript = Join-Path $resourcePackDir "generate_textures.py"
    if (Test-Path $pythonScript) {
        try {
            $pythonPath = (Get-Command python).Source
            & $pythonPath $pythonScript
            Write-Host "[OK] Texturen erfolgreich generiert!" -ForegroundColor $Success
        } catch {
            Write-Host "[WARNING] Python nicht verfügbar" -ForegroundColor $Warning
            Write-Host "  - Installiere Python: https://www.python.org/" -ForegroundColor $Warning
            Write-Host "  - Oder erstelle Texturen manuell" -ForegroundColor $Warning
        }
    }
    Write-Host ""
}

# === OVERWRITE CHECK ===
if (Test-Path $outputZip) {
    Write-Host "[2/3] Lösche alte Resource Pack ZIP..." -ForegroundColor $Info
    Remove-Item -Path $outputZip -Force
    Write-Host "[OK] Alte ZIP gelöscht" -ForegroundColor $Success
    Write-Host ""
}

# === KOMPRESSION ===
if (-not $SkipCompress) {
    Write-Host "[3/3] Komprimiere Resource Pack zu ZIP..." -ForegroundColor $Info
    
    try {
        Compress-Archive -Path "$resourcePackDir\*" `
                         -DestinationPath $outputZip `
                         -Force
        
        $zipSize = (Get-Item $outputZip).Length
        $zipSizeMB = [math]::Round($zipSize / 1MB, 2)
        
        Write-Host "[OK] Erfolgreich komprimiert!" -ForegroundColor $Success
        Write-Host "    Dateigröße: $zipSizeMB MB" -ForegroundColor $Success
        
    } catch {
        Write-Host "[ERROR] Fehler beim Komprimieren: $_" -ForegroundColor $Error
        exit 1
    }
}

# === SUCCESS ===
Write-Host ""
Write-Host "========================================" -ForegroundColor $Success
Write-Host "[SUCCESS] Resource Pack erstellt!" -ForegroundColor $Success
Write-Host "========================================" -ForegroundColor $Success
Write-Host ""
Write-Host "Datei: $outputZip" -ForegroundColor $Info
Write-Host ""
Write-Host "Nächste Schritte:" -ForegroundColor $Info
Write-Host "1. Kopiere die ZIP zum Server:" -ForegroundColor $Info
Write-Host "   $outputZip" -ForegroundColor $Info
Write-Host "   → c:\Users\Simon\Desktop\Development\Minecraft\PAPER-1.21.11\resourcepacks\" -ForegroundColor $Info
Write-Host ""
Write-Host "2. Bearbeite server.properties:" -ForegroundColor $Info
Write-Host "   resource-pack=LobbySelector-RP.zip" -ForegroundColor $Info
Write-Host "   require-resource-pack=true" -ForegroundColor $Info
Write-Host ""
Write-Host "3. Starte den Server neu" -ForegroundColor $Info
Write-Host ""
