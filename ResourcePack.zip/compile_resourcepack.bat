@echo off
REM LobbySelector Resource Pack - Compile Script
REM Kompiliert das Resource Pack zu einer ZIP-Datei

setlocal enabledelayedexpansion

echo.
echo ========================================
echo  LobbySelector - Resource Pack Compiler
echo ========================================
echo.

set "SCRIPT_DIR=%~dp0"
set "RESOURCEPACK_DIR=%SCRIPT_DIR%ResourcePack"
set "OUTPUT_DIR=%SCRIPT_DIR%"
set "OUTPUT_ZIP=%OUTPUT_DIR%LobbySelector-RP.zip"

REM Überprüfe ob Verzeichnis existiert
if not exist "%RESOURCEPACK_DIR%" (
    echo [ERROR] ResourcePack Verzeichnis nicht gefunden: %RESOURCEPACK_DIR%
    pause
    exit /b 1
)

echo [1/3] Generiere Texturen mit Python...
cd /d "%RESOURCEPACK_DIR%"

python generate_textures.py
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] Python Script fehlgeschlagen oder Python nicht installiert
    echo [INFO] Du kannst Texturen auch manuell erstellen (s. TEXTUR_ANLEITUNG.md)
)

echo.
echo [2/3] Überprüfe pack.mcmeta...
if not exist "%RESOURCEPACK_DIR%\pack.mcmeta" (
    echo [ERROR] pack.mcmeta nicht gefunden!
    pause
    exit /b 1
)
echo [OK] pack.mcmeta gefunden

echo.
echo [3/3] Kompiliere Resource Pack zu ZIP...

REM Lösche alte ZIP falls vorhanden
if exist "%OUTPUT_ZIP%" (
    echo [INFO] Lösche alte ZIP: %OUTPUT_ZIP%
    del /f /q "%OUTPUT_ZIP%"
)

REM Komprimiere mit Windows PowerShell
powershell -Command "Compress-Archive -Path '%RESOURCEPACK_DIR%\*' -DestinationPath '%OUTPUT_ZIP%' -Force"

if %ERRORLEVEL% EQU 0 (
    echo [OK] Erfolgreich komprimiert!
    echo.
    echo ========================================
    echo [SUCCESS] Resource Pack erstellt!
    echo ========================================
    echo.
    echo Datei: %OUTPUT_ZIP%
    echo Größe: 
    dir /s "%OUTPUT_ZIP%"
    echo.
    echo Nächste Schritte:
    echo 1. Kopiere die ZIP auf den Server:
    echo    %SCRIPT_DIR%..\Minecraft\PAPER-1.21.11\resourcepacks\
    echo.
    echo 2. Starte den Server neu
    echo.
    echo 3. Oder bearbeite server.properties:
    echo    resource-pack=LobbySelector-RP.zip
    echo    require-resource-pack=true
) else (
    echo [ERROR] Fehler beim Komprimieren!
    pause
    exit /b 1
)

echo.
pause
