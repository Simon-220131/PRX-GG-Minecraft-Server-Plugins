# 🎨 Resource Pack - Textur Anleitung

## 📁 Textur-Verzeichnis Struktur

```
ResourcePack/
└── assets/minecraft/textures/custom/
    ├── royale_mode.png          (64x64 px - ROYALE Mode Icon)
    ├── swords_mode.png          (64x64 px - SWORDS Mode Icon)
    ├── lobby_mode.png           (64x64 px - LOBBY Mode Icon)
    ├── tropical_fish_custom.png (16x16 px - Sharks Item)
    └── treasure_chest.png       (64x64 px - Treasure Chest Icon)
```

## 🎯 Texturen erstellen

### 1. Tools für Textur-Erstellung
- **Photoshop** - Professional
- **GIMP** (kostenlos) - https://www.gimp.org/
- **Aseprite** (Pixel-Art) - https://www.aseprite.org/
- **Piskel** (Online, kostenlos) - https://www.piskelapp.com/
- **Paint.NET** (kostenlos) - https://www.getpaint.net/

### 2. Texturgröße
- **Item Texturen**: 16x16 oder 32x32 Pixel (für GUI besser 64x64)
- **Block Texturen**: 16x16 Pixel
- **Format**: PNG mit Transparenz

### 3. Minecraft Textur Palette

#### ROYALE Mode - Gold/Glänzend Effekt
```
Farben:
- Gold: #FFD700 oder #FFC000
- Hell: #FFFF00
- Schatten: #AA8800
- Akzent: #FF6B6B (Rot Hervorhebung)
```

**Design-Idee:**
```
[G] = Gold, [H] = Hell, [S] = Schatten, [R] = Rot
[S][S][S][S][S][S][S][S]
[S][H][H][H][H][H][H][S]
[S][H][G][G][G][G][H][S]
[S][H][G][R][R][G][H][S]
[S][H][G][R][R][G][H][S]
[S][H][G][G][G][G][H][S]
[S][H][H][H][H][H][H][S]
[S][S][S][S][S][S][S][S]
```

#### SWORDS Mode - Rot/Scharf Effekt
```
Farben:
- Rot: #FF4444
- Hellrot: #FF8888
- Schwarz: #222222
- Silber: #CCCCCC
```

**Design-Idee (gekreuzte Schwerter):**
```
[B][B][B][B][R][B][B][B]
[B][B][B][R][R][R][B][B]
[B][B][R][R][R][R][R][B]
[B][R][R][R][R][R][R][R]
[R][R][R][R][R][R][R][R]
[B][R][R][R][R][R][R][R]
[B][B][R][R][R][R][R][B]
[B][B][B][R][R][R][B][B]
```

#### LOBBY Mode - Blau/Welten Effekt
```
Farben:
- Blau: #0066FF
- Hellblau: #6699FF
- Dunkelblau: #003366
- Grün: #00FF00 (Für Eingang)
```

**Design-Idee (offene Tür mit Welt):**
```
[D][D][D][D][D][D][D][D]
[D][L][L][H][H][L][L][D]
[D][L][G][H][H][G][L][D]
[D][H][H][H][H][H][H][D]
[D][H][B][B][B][B][H][D]
[D][H][B][B][B][B][H][D]
[D][L][G][H][H][G][L][D]
[D][D][D][D][D][D][D][D]
```

## 📝 JSON Model Anpassungen

### Beispiel: Custom Model mit 3D-Effekt

```json
{
  "parent": "item/handheld",
  "textures": {
    "layer0": "custom/royale_mode"
  },
  "display": {
    "gui": {
      "rotation": [20, -40, -20],
      "translation": [2, 3, 0],
      "scale": [0.8, 0.8, 0.8]
    },
    "head": {
      "rotation": [0, 180, 0],
      "translation": [0, 0, 0],
      "scale": [1, 1, 1]
    },
    "thirdperson_righthand": {
      "rotation": [0, -90, 55],
      "translation": [0, 4, 0.5],
      "scale": [0.85, 0.85, 0.85]
    },
    "firstperson_righthand": {
      "rotation": [0, -90, 25],
      "translation": [1.13, 3.2, 1.13],
      "scale": [0.68, 0.68, 0.68]
    }
  }
}
```

## 🖼️ Texture Template Generator

```python
# Python Script zum Generieren von Test-Texturen
from PIL import Image, ImageDraw

# ROYALE Texture erstellen
img = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

# Gold background
draw.rectangle([(4, 4), (60, 60)], fill=(255, 215, 0, 255), outline=(170, 136, 0, 255))

# Highlights
for i in range(8, 56, 12):
    draw.rectangle([(i, 8), (i+6, 14)], fill=(255, 255, 0, 255))
    
img.save('royale_mode.png')
```

## 🔗 Texture Packs zum Inspirieren

- **Programmer Art** (Vanilla)
- **Faithful 64x** - https://faithfulpack.net/
- **PureBD Craft** - Professional Textures
- **Mizuno's 16 Craft** - High Quality

## ✅ Textur-Checkliste

- ☐ PNG Format (RGBA, mit Transparenz)
- ☐ 16x16, 32x32 oder 64x64 Pixel
- ☐ Passende Farben (s.o. Paletten)
- ☐ Keine harten Übergänge (etwas smoothen)
- ☐ Dekoration/Details hinzufügen
- ☐ Auf Minecraft-Look testen
- ☐ JSON Model anpassen (Rotation/Scale)

## 📦 Textur Installation

1. **Textur als PNG speichern:**
   ```
   royale_mode.png → ResourcePack/assets/minecraft/textures/custom/
   ```

2. **JSON Model anpassen** (falls nötig)

3. **Resource Pack kompilieren:**
   ```powershell
   Compress-Archive -Path "ResourcePack" -DestinationPath "LobbySelector-RP.zip"
   ```

4. **Auf Server instalieren:**
   ```
   Paper-Server/resourcepacks/LobbySelector-RP.zip
   ```

5. **In server.properties aktivieren:**
   ```properties
   resource-pack=LobbySelector-RP.zip
   require-resource-pack=true
   resource-pack-sha1=<HASH>
   ```

## 🎨 Farb-Referenzen

| Farbe | Hex | RGB | Verwendung |
|-------|-----|-----|-----------|
| Gold | #FFD700 | (255, 215, 0) | ROYALE |
| Rot | #FF4444 | (255, 68, 68) | SWORDS |
| Blau | #0066FF | (0, 102, 255) | LOBBY |
| Grün | #00FF00 | (0, 255, 0) | Hervorhebung |
| Schwarz | #000000 | (0, 0, 0) | Outline |
| Grau | #999999 | (153, 153, 153) | Schatten |

---

**Benötigte Texturen:**
```
custom/royale_mode.png
custom/swords_mode.png
custom/lobby_mode.png
custom/tropical_fish_custom.png
custom/treasure_chest.png
```

Alle Texturen müssen in `assets/minecraft/textures/custom/` abgelegt werden.
