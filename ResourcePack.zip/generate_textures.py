#!/usr/bin/env python3
"""
LobbySelector Resource Pack - Texture Generator
Generiert automatisch Platzhalter-Texturen für das GUI
"""

from PIL import Image, ImageDraw, ImageFont
import os

# Verzeichnis erstellen
output_dir = os.path.join(os.path.dirname(__file__), "assets/minecraft/textures/custom")
os.makedirs(output_dir, exist_ok=True)

# ============ Texture Generator Functions ============

def create_royale_texture(size=64):
    """Erstellt die ROYALE Mode Textur (Gold mit Glanz)"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Gold Hintergrund
    draw.rectangle([(4, 4), (size-4, size-4)], 
                   fill=(255, 215, 0, 255), 
                   outline=(170, 136, 0, 255), 
                   width=2)
    
    # Innen-Rahmen
    draw.rectangle([(8, 8), (size-8, size-8)], 
                   outline=(255, 255, 0, 255), 
                   width=1)
    
    # Glanz-Highlights
    for i in range(10, size-10, 16):
        draw.polygon([(i, 12), (i+6, 12), (i+3, 18)], 
                     fill=(255, 255, 150, 200))
    
    # Zentrum Stern
    star_x, star_y = size // 2, size // 2
    star_size = 12
    for angle in range(0, 360, 72):
        import math
        rad = math.radians(angle)
        x = star_x + star_size * math.cos(rad)
        y = star_y + star_size * math.sin(rad)
        draw.line([(star_x, star_y), (x, y)], fill=(255, 255, 0, 255), width=1)
    
    # Speichern
    output_path = os.path.join(output_dir, "royale_mode.png")
    img.save(output_path)
    print(f"✓ Erstellt: {output_path}")
    return output_path

def create_swords_texture(size=64):
    """Erstellt die SWORDS Mode Textur (Gekreuzte Schwerter)"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Schatten Hintergrund
    draw.rectangle([(4, 4), (size-4, size-4)], 
                   fill=(40, 40, 40, 255), 
                   outline=(100, 0, 0, 255), 
                   width=2)
    
    # Erstes Schwert (von links oben nach rechts unten)
    draw.polygon([
        (12, 16),
        (18, 10),
        (size-10, size-2),
        (size-16, size+4),
        (size-4, size-4),
    ], fill=(200, 50, 50, 255))
    
    # Zweites Schwert (von rechts oben nach links unten)
    draw.polygon([
        (size-12, 16),
        (size-18, 10),
        (10, size-2),
        (16, size+4),
        (4, size-4),
    ], fill=(255, 100, 100, 255))
    
    # Kreuzungs-Punkt
    draw.ellipse([(size//2-6, size//2-6), (size//2+6, size//2+6)],
                 fill=(220, 80, 80, 255), outline=(255, 200, 200, 255), width=1)
    
    # Speichern
    output_path = os.path.join(output_dir, "swords_mode.png")
    img.save(output_path)
    print(f"✓ Erstellt: {output_path}")
    return output_path

def create_lobby_texture(size=64):
    """Erstellt die LOBBY Mode Textur (Offene Tür mit Welt)"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Türrahmen (Braun)
    draw.rectangle([(4, 4), (size-4, size-4)], 
                   fill=(139, 69, 19, 255), 
                   outline=(101, 50, 15, 255), 
                   width=2)
    
    # Türen-Fenster (Blau = Welt)
    draw.rectangle([(8, 8), (size-8, size-8)], 
                   fill=(0, 100, 200, 255))
    
    # Grüne Vegetation (kleine Punkte)
    import random
    random.seed(42)  # Für konsistente Ergebnisse
    for _ in range(8):
        x = random.randint(12, size-12)
        y = random.randint(12, size-12)
        draw.polygon([(x-2, y), (x, y-2), (x+2, y), (x, y+2)],
                     fill=(50, 200, 50, 255))
    
    # Griff (Gelblich)
    draw.rectangle([(size-8, size//2-3), (size-6, size//2+3)],
                   fill=(255, 200, 0, 255))
    
    # Speichern
    output_path = os.path.join(output_dir, "lobby_mode.png")
    img.save(output_path)
    print(f"✓ Erstellt: {output_path}")
    return output_path

def create_tropical_fish_texture(size=16):
    """Erstellt die Tropical Fish / Sharks Textur"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Fisch-Body (Rot/Orange)
    draw.ellipse([(2, 4), (12, 10)], fill=(200, 50, 50, 255))
    
    # Fisch-Kopf
    draw.polygon([(12, 4), (14, 7), (12, 10)], fill=(180, 40, 40, 255))
    
    # Fisch-Schwanz
    draw.polygon([(2, 6), (0, 4), (0, 8), (2, 8)], fill=(150, 30, 30, 255))
    
    # Auge
    draw.ellipse([(10, 5), (11, 6)], fill=(255, 255, 255, 255))
    draw.ellipse([(10, 5), (11, 6)], outline=(0, 0, 0, 255), width=1)
    
    # Speichern
    output_path = os.path.join(output_dir, "tropical_fish_custom.png")
    img.save(output_path)
    print(f"✓ Erstellt: {output_path}")
    return output_path

def create_treasure_chest_texture(size=64):
    """Erstellt die Treasure Chest Textur"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Kiste Körper (Braun)
    draw.rectangle([(8, 16), (size-8, size-4)], 
                   fill=(139, 100, 50, 255), 
                   outline=(101, 70, 35, 255), 
                   width=2)
    
    # Deckel oben (3D Effekt)
    draw.polygon([(8, 16), (size-8, 16), (size-6, 12), (10, 12)],
                 fill=(180, 130, 70, 255))
    
    # Schloss (Gold)
    draw.rectangle([(size//2-4, 20), (size//2+4, 26)], 
                   fill=(255, 215, 0, 255))
    
    # Schätze im Inneren (Punkte)
    draw.polygon([(14, 32), (16, 28), (18, 32)], fill=(255, 215, 0, 255))
    draw.polygon([(size-18, 32), (size-16, 28), (size-14, 32)], fill=(255, 215, 0, 255))
    draw.ellipse([(size//2-3, 30), (size//2+3, 36)], fill=(200, 100, 100, 255))
    
    # Speichern
    output_path = os.path.join(output_dir, "treasure_chest.png")
    img.save(output_path)
    print(f"✓ Erstellt: {output_path}")
    return output_path

# ============ Main ============

if __name__ == "__main__":
    print("=" * 50)
    print(" LobbySelector - Texture Generator")
    print("=" * 50)
    print()
    
    try:
        create_royale_texture()
        create_swords_texture()
        create_lobby_texture()
        create_tropical_fish_texture()
        create_treasure_chest_texture()
        
        print()
        print("=" * 50)
        print("✓ Alle Texturen erfolgreich erstellt!")
        print("=" * 50)
        print()
        print("Texturen befinden sich in:")
        print(f"  {output_dir}")
        print()
        print("Nächste Schritte:")
        print("1. Texturen verbessern (optional, mit GIMP/Photoshop)")
        print("2. Resource Pack kompilieren")
        print("3. Auf Server installieren")
        
    except Exception as e:
        print(f"✗ Fehler beim Erstellen der Texturen: {e}")
        import traceback
        traceback.print_exc()
